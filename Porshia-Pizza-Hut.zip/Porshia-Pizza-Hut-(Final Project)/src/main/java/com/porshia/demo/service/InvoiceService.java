package com.porshia.demo.service;

import com.porshia.demo.model.Invoice;

public interface InvoiceService 
{
		public void saveInvoice(Invoice invoice);
		
}
