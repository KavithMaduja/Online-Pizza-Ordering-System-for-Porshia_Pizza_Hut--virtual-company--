package com.porshia.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="porshia_invoice")
public class Invoice
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "invoice_no")
	private int no;

	@Column(name = "name")
	private String na;

	@Column(name = "supremePizza_price")
	private String sp;

	@Column(name = "baconSpinachPizza_price")
	private String bp;	

	@Column(name = "mozzarellaStuffedPizza_price")
	private String mp;
	
	@Column(name = "total_amount")
	private String t;

	@Column(name="date")
	private String invoicedate;

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getNa() {
		return na;
	}

	public void setNa(String na) {
		this.na = na;
	}

	public String getSp() {
		return sp;
	}

	public void setSp(String sp) {
		this.sp = sp;
	}

	public String getBp() {
		return bp;
	}

	public void setBp(String bp) {
		this.bp = bp;
	}

	public String getMp() {
		return mp;
	}

	public void setMp(String mp) {
		this.mp = mp;
	}

	public String getT() {
		return t;
	}

	public void setT(String t) {
		this.t = t;
	}

	public String getInvoicedate() {
		return invoicedate;
	}

	public void setInvoicedate(String invoicedate) {
		this.invoicedate = invoicedate;
	}

	@Override
	public String toString() {
		return "Invoice [no=" + no + ", na=" + na + ", sp=" + sp + ", bp=" + bp + ", mp=" + mp + ", t=" + t
				+ ", invoicedate=" + invoicedate + "]";
	}
	
	
}
