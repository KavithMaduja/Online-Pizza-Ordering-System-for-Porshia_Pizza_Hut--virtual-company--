package com.porshia.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.porshia.demo.model.User;

@Repository
public interface MemberRepository extends CrudRepository<User, Integer> 
{

}
