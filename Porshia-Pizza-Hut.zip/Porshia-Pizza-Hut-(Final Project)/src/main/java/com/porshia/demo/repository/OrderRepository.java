package com.porshia.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.porshia.demo.model.Pizza;

@Repository
public interface OrderRepository extends CrudRepository<Pizza, Integer>
{

}
