package com.porshia.demo.service;

import java.util.List;


import com.porshia.demo.model.User;

public interface MemberService 
{
	List<User> findAll();
}
