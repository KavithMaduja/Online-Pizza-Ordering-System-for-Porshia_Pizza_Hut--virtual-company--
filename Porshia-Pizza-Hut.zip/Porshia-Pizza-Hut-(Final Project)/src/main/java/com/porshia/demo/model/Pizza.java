package com.porshia.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;


@Entity
@Table(name = "porshia_pizza")
public class Pizza 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "order_no")
	private int no;
	
	@NotNull(message = "name is compulsory")
	@NotBlank(message = "name is compulsory")
	@Column(name = "name")
	private String name;
	
	@NotNull(message = "address is compulsory")
	@NotBlank(message = "address is compulsory")
	@Column(name = "delivery_address")
	private String add;
	
	@Column(name="supremePizza_qty")
	private int sup;
	
	@Column(name="baconSpinachPizza_qty")
	private int bsa;
	
	@Column(name="mozzarellaStuffedPizza_qty")
	private String msc;
	
	@Column(name = "order_date")
	private String invoicedate;

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

	public int getSup() {
		return sup;
	}

	public void setSup(int sup) {
		this.sup = sup;
	}

	public int getBsa() {
		return bsa;
	}

	public void setBsa(int bsa) {
		this.bsa = bsa;
	}

	public String getMsc() {
		return msc;
	}

	public void setMsc(String msc) {
		this.msc = msc;
	}

	
	public String getInvoicedate() {
		return invoicedate;
	}

	public void setInvoicedate(String invoicedate) {
		this.invoicedate = invoicedate;
	}

	@Override
	public String toString() {
		return "Pizza [no=" + no + ", name=" + name + ", add=" + add + ", sup=" + sup + ", bsa=" + bsa + ", msc=" + msc
				+ ", invoicedate=" + invoicedate + "]";
	}

	
	

	

		
}
