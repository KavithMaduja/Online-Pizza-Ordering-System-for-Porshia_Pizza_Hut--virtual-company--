package com.porshia.demo.service;

import com.porshia.demo.model.Pizza;

public interface PizzaService
{
	public void savePizza(Pizza pizza);
}
