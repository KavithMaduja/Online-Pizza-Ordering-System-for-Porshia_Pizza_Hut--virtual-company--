package com.porshia.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.porshia.demo.model.Pizza;
import com.porshia.demo.repository.PizzaRepository;

@Service
public class PizzaServiceImp implements PizzaService
{
	@Autowired
	PizzaRepository pizzaRepository;

	@Override
	public void savePizza(Pizza pizza)
	{
		pizzaRepository.save(pizza);
	}

}
