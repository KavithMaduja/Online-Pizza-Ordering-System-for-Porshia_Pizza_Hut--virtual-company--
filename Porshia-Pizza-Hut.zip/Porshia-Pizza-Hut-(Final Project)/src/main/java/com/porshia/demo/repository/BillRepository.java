package com.porshia.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.porshia.demo.model.Invoice;

@Repository
public interface BillRepository extends CrudRepository<Invoice, Integer>
{

}
