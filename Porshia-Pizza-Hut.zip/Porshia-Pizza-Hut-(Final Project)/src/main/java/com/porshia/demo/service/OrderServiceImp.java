package com.porshia.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.porshia.demo.model.Pizza;
import com.porshia.demo.repository.OrderRepository;

@Service("OrderService")
public class OrderServiceImp implements OrderService
{
	@Autowired
    private OrderRepository repository;

    @Override
    public List<Pizza> findAll() {

        return (List<Pizza>) repository.findAll();
    }
}
