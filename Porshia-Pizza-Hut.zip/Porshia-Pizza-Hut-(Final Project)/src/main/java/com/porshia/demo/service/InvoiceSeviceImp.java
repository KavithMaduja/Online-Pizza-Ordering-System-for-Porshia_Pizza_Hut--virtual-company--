package com.porshia.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.porshia.demo.model.Invoice;

import com.porshia.demo.repository.InvoiceRepository;

@Service
public class InvoiceSeviceImp implements InvoiceService
{
	@Autowired
	InvoiceRepository invoiceRepository;

	@Override
	public void saveInvoice(Invoice invoice) {
		invoiceRepository.save(invoice);
	}

}
