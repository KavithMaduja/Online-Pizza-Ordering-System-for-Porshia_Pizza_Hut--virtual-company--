package com.porshia.demo.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.porshia.demo.model.Invoice;
import com.porshia.demo.model.Pizza;
import com.porshia.demo.model.User;
import com.porshia.demo.service.BillService;
import com.porshia.demo.service.InvoiceService;
import com.porshia.demo.service.MemberService;
import com.porshia.demo.service.OrderService;
import com.porshia.demo.service.PizzaService;
import com.porshia.demo.service.UserService;


@Controller
public class AuthenticationController 
{
	@Autowired
	UserService userService;
	
	@Autowired
	private MemberService memberService;
	
	@Autowired
	PizzaService pizzaService;
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	InvoiceService invoiceService;
	
	@Autowired
	private BillService billService;
	
	@RequestMapping(value = { "/home" }, method = RequestMethod.GET)
	public ModelAndView home() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("home");  
		return modelAndView;
	}
	
	@RequestMapping(value = { "/login" }, method = RequestMethod.GET)
	public ModelAndView login() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login"); 
		return modelAndView;
	}

	
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView register() {
		ModelAndView modelAndView = new ModelAndView();
		 User user = new User();
		 modelAndView.addObject("user", user); 
		modelAndView.setViewName("register");
		return modelAndView;
	}
	
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("index"); 
		return modelAndView;
	}
	
	
	@RequestMapping(value = "/adminHome", method = RequestMethod.GET)
	public ModelAndView adminHome() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("adminHome");
		return modelAndView;
	}
	
	@RequestMapping(value = "/pizzaOrder", method = RequestMethod.GET)
	public ModelAndView pizzaOrder() {
		ModelAndView modelAndView = new ModelAndView();
		 Pizza pizza = new Pizza();
		 modelAndView.addObject("pizza", pizza); 
		modelAndView.setViewName("pizzaOrder");
		return modelAndView;
	}
	
		/* Register Customer*/
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public ModelAndView registerUser(@Valid User user, BindingResult bindingResult, ModelMap modelMap) {
		ModelAndView modelAndView = new ModelAndView();
		// Check for the validations
		if(bindingResult.hasErrors()) {
			modelAndView.addObject("successMessage", "Please correct the errors in form!");
			modelMap.addAttribute("bindingResult", bindingResult);
		}
		else if(userService.isUserAlreadyPresent(user)){
			modelAndView.addObject("successMessage", "user already exists!");			
		}
		// we will save the user if, no binding errors
		else {
			userService.saveUser(user);
			modelAndView.addObject("successMessage", "User is registered successfully!");
		}
		modelAndView.addObject("user", new User());
		modelAndView.setViewName("register");
		return modelAndView;
	}
	
		// *** Get All Customers *** //	
	    @GetMapping("/viewMembers")
	    public String viewMembers(Model model)
	 	{
		 	model.addAttribute("users", memberService.findAll());
		    return "viewMembers";
	    }
	    
	    
	    	// **** Submit new Order & Save Invoice details*** //
		@RequestMapping(value="/pizzaOrder", method=RequestMethod.POST)
		public ModelAndView submitOrder(@Valid Pizza pizza,@Valid Invoice invoice, BindingResult bindingResult, ModelMap modelMap) throws IOException
		{
			ModelAndView modelAndView = new ModelAndView();
			// Check for the validations
			if(bindingResult.hasErrors()) {
				modelAndView.addObject("successMessage", "Please correct the errors in form!");
				modelMap.addAttribute("bindingResult", bindingResult);
			}
			else {
				pizzaService.savePizza(pizza);
				invoiceService.saveInvoice(invoice);
				modelAndView.addObject("successMessage", "Order is confirmed!");
			}
			modelAndView.addObject("pizza", new Pizza());
			modelAndView.addObject("invoice", new Invoice());
			modelAndView.setViewName("pizzaOrder");
			return modelAndView;
		} 
		
		// *** Get All Orders *** //	
	    @GetMapping("/viewOrders")
	    public String viewOrders(Model model)
	 	{
		 	model.addAttribute("pizzas", orderService.findAll());
		    return "viewOrders";
	    }

	
	// *** Get All Invoices *** //	
    @GetMapping("/viewInvoices")
    public String viewInvoices(Model model)
 	{
	 	model.addAttribute("invoices", billService.findAll());
	    return "viewInvoices";
    }
	    
}
