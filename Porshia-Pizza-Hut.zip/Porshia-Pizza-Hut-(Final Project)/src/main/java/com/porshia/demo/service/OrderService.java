package com.porshia.demo.service;

import java.util.List;

import com.porshia.demo.model.Pizza;

public interface OrderService
{
	List<Pizza> findAll();
}
