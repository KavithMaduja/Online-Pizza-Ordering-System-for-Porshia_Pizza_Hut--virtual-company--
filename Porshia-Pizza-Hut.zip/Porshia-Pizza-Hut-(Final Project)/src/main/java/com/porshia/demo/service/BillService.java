package com.porshia.demo.service;

import java.util.List;

import com.porshia.demo.model.Invoice;

public interface BillService
{
	List<Invoice> findAll();
}
