package com.porshia.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.porshia.demo.model.Invoice;
import com.porshia.demo.repository.BillRepository;

@Service("BillService")
public class BillServiceImp implements BillService
{
	@Autowired
    private BillRepository repository;

    @Override
    public List<Invoice> findAll() {

        return (List<Invoice>) repository.findAll();
    }
}
