package com.porshia.demo.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name ="porshia_user")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "porshia_user_id")
	private int id;

	@NotNull(message="name is compulsory")
	@NotBlank(message="name is compulsory")
	@Column(name = "name")
	private String name;

	@NotNull(message="email is compulsory")
	@NotBlank(message="email is compulsory")
	@Email(message = "email is invalid")
	@Column(name = "email")
	private String email;

	@NotNull(message="contactno is compulsory")
	@Length(min=10,max=10, message="conatctno must have 10 numbers")
	@Column(name = "contact_no")
	private String contactno;
	
	@Column(name="register_date")
	private String registerdate;
	
	@NotNull(message="password is compulsory")
	@Length(min=5, message="password should be at least 5 characters")
	@Column(name = "password")
	private String password;

	@Column(name = "status")
	private String status;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "porshia_user_role", joinColumns = @JoinColumn(name = "porshia_user_id"), inverseJoinColumns = @JoinColumn(name = "porshia_role_id"))
	private Set<Role> roles;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public String getRegisterdate() {
		return registerdate;
	}

	public void setRegisterdate(String registerdate) {
		this.registerdate = registerdate;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", email=" + email + ", contactno=" + contactno + ", registerdate="
				+ registerdate + ", password=" + password + ", status=" + status + ", roles=" + roles + "]";
	}

	
	
		
}
