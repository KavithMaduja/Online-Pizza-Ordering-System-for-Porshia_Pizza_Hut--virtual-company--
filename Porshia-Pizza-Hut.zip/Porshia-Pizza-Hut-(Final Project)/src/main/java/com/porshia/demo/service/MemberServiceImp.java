package com.porshia.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.porshia.demo.model.User;
import com.porshia.demo.repository.MemberRepository;
import com.porshia.demo.service.MemberService;


@Service("MemberService")
public class MemberServiceImp implements MemberService
{
	 @Autowired
	    private MemberRepository repository;

	    @Override
	    public List<User> findAll() {

	        return (List<User>) repository.findAll();
	    }
}