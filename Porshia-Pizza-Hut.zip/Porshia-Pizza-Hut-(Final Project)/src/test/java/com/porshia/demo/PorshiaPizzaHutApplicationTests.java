package com.porshia.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PorshiaPizzaHutApplicationTests {

	@Test
	void contextLoads() {
	}

}
